#ifndef THREED_H
#define THREED_H

#include <iostream>
#include "shape.h"

class ThreeDimensionalShape : public Shape{
public:
	ThreeDimensionalShape(double x, double y,double z);
	//virtual ~ThreeDimensionalShape();
	virtual void print() const =0 ;
	virtual double area() const=0;
	virtual double volume() const=0;

	double x_center{};
	double y_center{};
	double z_center{};
};


#endif