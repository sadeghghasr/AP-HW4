#include "twod.h"


//constructor:
TwoDimensionalShape::TwoDimensionalShape(double x, double y) :Shape(){
	x_center = x;
	y_center = y;
}