#include "sphere.h"

Sphere::Sphere(double r, double x, double y) : ThreeDimensionalShape(x,y,0)
{
	radius = r;
}

double Sphere::area() const
{
	return 4*3.141592*radius*radius;
}

double Sphere::volume() const
{
	return 1.333333333333*3.141592*radius*radius*radius;
}

void Sphere::print() const
{
	std::cout<<"Sphere radius = "<<this->radius<<'\n'
	 << "center -> (" << this->x_center <<','<<this->y_center
	<<','<<this->z_center<<" ) \n"
	 << "area of " << this->area() << " & volume of " <<
	this->volume()<<"\n";
}


Sphere& Sphere::operator + (Point p)
{
	this->x_center += p._x;
	this->y_center += p._y;
	this->z_center += p._z;
	return *this;
}