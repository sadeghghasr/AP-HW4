#include "circle.h"
#include "twod.h"


Circle::Circle(double r,double x,double y) : TwoDimensionalShape(x,y)
{
	radius = r;
}

double Circle::area() const
{
	return 3.141592*radius*radius;
}

/*double Circle::volume() const
{
	return 3.192*radius*radius;
}
*/
void Circle::print() const
{
	std::cout<<"Circle radius = "<<this->radius<<'\n'
	 << "center -> (" << this->x_center <<','<<this->y_center
	<<" ) \n"
	 << "area of " << this->area() << "\n";
}

Circle& Circle::operator + (Point p)
{
	this->x_center += p._x;
	this->y_center += p._y;
	return *this;
}