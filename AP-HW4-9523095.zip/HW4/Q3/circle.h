#ifndef CIRCLE_H
#define CIRCLE_H

#include <iostream>
#include "twod.h"
#include "point.h"
class Circle : public TwoDimensionalShape{
public:
	//constructor and dis. :
	Circle(double r,double x,double y);
	//virtual ~Circle();
	//functions:
	virtual double area() const;
	virtual void print() const;
	virtual Circle& operator + (Point p);
	//virtual double volume() const;
	//variables:
	double radius{};

};

#endif