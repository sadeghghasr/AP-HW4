#ifndef SPHERE_H
#define SPHERE_H

#include "threed.h"
#include "point.h"

class Sphere : public ThreeDimensionalShape{
public:
	Sphere(double r,double x,double y);
	//virtual ~Sphere();
	virtual double area() const;
	virtual double volume()const;
	virtual void print() const;
	virtual Sphere& operator + (Point p);

	double radius{};
};


#endif