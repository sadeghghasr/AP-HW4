#ifndef SQUARE_H
#define SQUARE_H

#include "twod.h"
#include "point.h"
class Square : public TwoDimensionalShape{
public:
	Square(double s,double x,double y);
	//virtual ~Square();
	virtual double area() const;
	virtual void print() const;
	virtual Square& operator + (Point p);
	//virtual double volume() const;
	double side{};
};

#endif