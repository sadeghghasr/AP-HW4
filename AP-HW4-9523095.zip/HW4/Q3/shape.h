#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>
#include "point.h"

class Shape{
public:
	Shape();
	friend std::ostream& operator<<(std::ostream& test,Shape& c){
	c.print();
	/*test << "Cube side length = "<<c.side<<'\n';
	test << "center -> (" << c.x_center <<','<<c.y_center
	<<','<<c.z_center<<" ) \n";
	test << "area of " << c.area() << " & volume of " <<
	c.volume()<<" ,,,,, "<< c.print();*/
	return test;
	}
	//virtual double area() const=0;
	//virtual double volume() const=0;
	//virtual ~Shape();
	virtual void print() const=0;
	virtual Shape& operator+ (Point p) = 0;
};




#endif