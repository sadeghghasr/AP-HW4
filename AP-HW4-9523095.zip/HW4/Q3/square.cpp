#include "square.h"


Square::Square(double s,double x,double y) : TwoDimensionalShape::TwoDimensionalShape(x,y)
{
	side = s;
}

double Square::area() const
{
	return side * side;
}

void Square::print() const
{
	std::cout<<"Square side length = "<<this->side<<'\n'
	 << "center -> (" << this->x_center <<','<<this->y_center
	<<" ) \n"
	 << "area of " << this->area() << "\n";
}

Square& Square::operator + (Point p)
{
	this->x_center += p._x;
	this->y_center += p._y;
	return *this;
}
/*double Square::volume() const
{
	return 3.192;
}
*/