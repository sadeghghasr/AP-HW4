#include "point.h"


Point::Point(double x, double y,double z)
{
	_x = x;
	_y = y;
	_z = z;
}