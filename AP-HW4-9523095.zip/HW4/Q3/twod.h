#ifndef TWOD_H
#define TWOD_H

#include "shape.h"

class TwoDimensionalShape : public Shape{
public:
	TwoDimensionalShape(double x, double y);
	virtual double area() const=0;
	//virtual double volume() const=0;
	//virtual ~TwoDimensionalShape();
	virtual void print() const =0;
	double x_center{};
	double y_center{};

};


#endif