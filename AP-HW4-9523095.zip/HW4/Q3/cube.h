#ifndef CUBE_H
#define CUBE_H

#include <iostream>
#include <sstream>
#include <string>
#include "threed.h"
#include "point.h"

class Cube : public ThreeDimensionalShape{
public:
	Cube(double s);
	double area() const;
	double volume() const;
	virtual void print() const;
	virtual Cube& operator + (Point p);
//	virtual ~Cube();
	double side{};
};

#endif