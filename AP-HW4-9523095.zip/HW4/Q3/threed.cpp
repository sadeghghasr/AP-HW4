#include "threed.h"


//constructor:
ThreeDimensionalShape::ThreeDimensionalShape(double x, double y,double z) : Shape(){
	x_center = x;
	y_center = y;
	z_center = z;
}