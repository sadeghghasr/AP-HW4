#include "cube.h"


Cube::Cube(double s):ThreeDimensionalShape(0,0,0) 
{
	side = s;
}

double Cube::area() const
{
	return 6*side*side;
}

double Cube::volume() const
{
	return side*side*side;
}

void Cube::print() const
{
	std::cout<<"Cube side length = "<<this->side<<'\n'
	 << "center -> (" << this->x_center <<','<<this->y_center
	<<','<<this->z_center<<" ) \n"
	 << "area of " << this->area() << " & volume of " <<
	this->volume()<<"\n";
}


Cube& Cube::operator + (Point p)
{
	this->x_center += p._x;
	this->y_center += p._y;
	this->z_center += p._z;
	return *this;
}
