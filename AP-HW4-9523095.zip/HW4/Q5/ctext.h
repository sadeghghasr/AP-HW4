#ifndef CTEXT_H
#define CTEXT_H

#include <iostream>
#include <cstring>

class CText{
public:
	CText(std::string);
	std::string getText();
private:
	std::string Value;
};
#endif