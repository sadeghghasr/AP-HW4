#include <iostream>
#include <memory>
#include <cstring>
#include "stack.hpp"
#include "ctext.h"


int main()
{
	Stack<std::shared_ptr<CText>> stack;
	std::string base{"TEXT"};

	for(char a{'A'}; a<= 'Z';a++)
		stack.push(std::make_shared<CText>(base + a));
	//stack.disp();
	
	int N{stack.getCount()};

	if(stack.isEmpty())
	{
		std::cout<<"Stack is empty"<<std::endl;
		return -1;
	}

	for(int i{};i<N;i++)
	{
		std::cout<<i+1<<" : "<<stack.pop()->getText() <<std::endl;
	}
	if(stack.isEmpty())
	{
		std::cout<<"Stack is empty"<<std::endl;
	}


	return 0;
}