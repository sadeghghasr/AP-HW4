#ifndef STACK_HPP
#define STACK_HPP

#include <typeinfo>
#include "stack.h"

template<class T>
Stack<T>::Stack()
{
	elements = new T[size];
}

template<class T>
void Stack<T>::push(const T& M)
{
	size++;
	T* p{new T[size]};
	for(size_t i{};i < size-1;i++)
		*(p+i) = elements[i];
	p[size - 1] = M;
	this->elements = p;
	p = nullptr;
	delete[] p;
}
/*template<class T>
void Stack<T>::disp()
{
	display(elements,size);
}*/

/*template<class T>
void Stack<T>::display(T* arr , size_t size)
{
	for(int i{} ; i < size;i++)
	{
		std::cout << *(arr[i]) << " ,";
	}
	std::cout<<std::endl;
}
*/
template<class T>
bool Stack<T>::isEmpty()
{
	return size == 0;
}

template<class T>
int Stack<T>::getCount()
{
	return size;
}

template<class T>
T Stack<T>::pop()
{
	T test{elements[size - 1]};
	size--;
	T* p{new T[size]};
	for(size_t i{};i < size;i++)
		*(p+i) = elements[i];
	this->elements = p;
	p = nullptr;
	delete[] p;
	return test;
}

#endif