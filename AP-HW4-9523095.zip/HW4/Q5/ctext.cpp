#include "ctext.h"


CText::CText(std::string A)
{
	Value = A;
}

std::string CText::getText()
{
	return Value;
}