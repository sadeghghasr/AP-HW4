#ifndef STACK_H
#define STACK_H

#include <iostream>



template<class T>
class Stack{
public:
	Stack();
	void push(const T& M);
	//void disp();
	//void display(T*,size_t);
	T pop();
	int getCount();
	bool isEmpty();

private:
	size_t size{};
	T* elements{new T[size]};
};

#endif 