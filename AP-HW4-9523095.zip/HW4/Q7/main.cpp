#include <iostream>
#include <algorithm>
#include <vector>
#include <random>
#include <cstdlib>
#include <array>
#include <ctime>


int main()
{
	std::vector<double> vec(50,4);
	//Part B:
	srand((unsigned)time(0));
	int n{(rand()%50) + 1};
	std::generate(std::begin(vec),std::end(vec),[](auto n){return n;});
    for (int i{}; i<50;i++)
    	std::cout << vec[i]<<std::endl;
	return 0;
}