#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <set>
#include <numeric>
#include <functional>


template<typename T>
void disp(const T& vec);
int myop (int x, int y) {return y;}
void myfunc(int& i){
	i = 2 * i;
}

int main()
{
	// Part "A":
	std::vector<int> vec{1,2,3,4,5,4,3,2,1};

	std::cout<<"the original vector is: ";
	disp(vec); 
    vec.erase(std::remove(begin(vec), end(vec), 2), end(vec));
	std::cout<<"the vector without any ((2)) is: ";
	disp(vec);

	// Part "B":
	vec = {1,2,3,4,5,4,3,2,1};
	std::cout << "the Dublicated:" << std::endl;
	for_each(vec.begin(),vec.end(),myfunc);
	disp(vec);
	
	// Part "C":
	double avg{std::accumulate(vec.begin(),vec.end(),0.0/vec.size())};
	//	Part "D":
	vec = {1,2,3,4,5,4,3,2,1};
	std::sort(vec.begin(), vec.end()); 
	auto last = std::unique(vec.begin(), vec.end());
	vec.erase(last, vec.end());
	disp(vec);

	// Part "E":
	vec = {1,2,3,4,5,4,3,2,1};
	std::set <int> set_type_of_vec(vec.begin(),vec.end());
	std::cout<<"set_type_of_vec is : ";		
	disp(set_type_of_vec);

	return 0;
}

template<typename T>
void disp(const T& vec)
{
	for(size_t i: vec)
	{
		std::cout << i<<", ";
	}
	std::cout<<"\n";
}