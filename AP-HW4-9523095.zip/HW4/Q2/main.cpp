#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include <iomanip>
#include <algorithm>

template <typename T>
int size(const std::vector<T>& v){return v.size();};

template <typename T>
int capacity(const std::vector<T>& v){return v.capacity();};

int main()
{
	double x{0.000000};
	double j{};
	std::vector<std::unique_ptr<std::string>> v;
	for(size_t i{}; i < 1000; i++)
	{
		std::string y{std::to_string(x +j).substr(2,3)};
		v.push_back(std::make_unique<std::string>("Str "+y));
		std::cout<<"The Size Of the Vector is: "<<size(v) <<std::endl;
		std::cout<<"The Capacity Of the Vector is: "<<capacity(v)<<std::endl;
		j = j + 0.001;
	}
	return 0;
}	
